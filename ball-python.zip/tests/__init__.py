"""Test package for pycleaner."""
